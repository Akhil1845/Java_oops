package com.microinternship.skillbridge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillBridgeApplicationTests {

    @Test
    void contextLoads() {
    }

}
