package com.microinternship.skillbridge.repository;

import com.microinternship.skillbridge.entity.Internship;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InternshipRepository extends JpaRepository<Internship, Long> {
}
