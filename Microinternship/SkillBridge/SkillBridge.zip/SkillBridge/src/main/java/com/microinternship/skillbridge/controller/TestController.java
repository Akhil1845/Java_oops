package com.microinternship.skillbridge.controller;

import com.microinternship.skillbridge.entity.Test;
import com.microinternship.skillbridge.service.TestService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tests")
@CrossOrigin(origins = "*")
public class TestController {

    private final TestService testService;

    public TestController(TestService testService) {
        this.testService = testService;
    }

    // Upload a new test
    @PostMapping
    public Test uploadTest(@RequestBody Test test) {
        return testService.saveTest(test);
    }

    // Get all tests
    @GetMapping
    public List<Test> getAllTests(@RequestParam(required = false) Long clientId) {
        if(clientId != null) {
            return testService.getTestsByClient(clientId);
        }
        return testService.getAllTests();
    }

    // Get a single test by ID
    @GetMapping("/{id}")
    public Optional<Test> getTest(@PathVariable Long id) {
        return testService.getTestById(id);
    }
}
