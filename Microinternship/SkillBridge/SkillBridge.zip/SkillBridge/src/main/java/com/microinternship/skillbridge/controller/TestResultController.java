package com.microinternship.skillbridge.controller;

import com.microinternship.skillbridge.entity.TestResult;
import com.microinternship.skillbridge.service.TestResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/results")
@CrossOrigin(origins = "http://localhost:3000") // adjust to your frontend origin
public class TestResultController {

    @Autowired
    private TestResultService resultService;

    // Add a new result
    @PostMapping
    public ResponseEntity<TestResult> addResult(@RequestBody TestResult result) {
        TestResult savedResult = resultService.saveResult(result);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedResult);
    }

    // Get results by student ID
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<TestResult>> getByStudent(@PathVariable Long studentId) {
        List<TestResult> results = resultService.getResultsByStudent(studentId);
        if (results.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(results);
    }

    // Get results by test ID
    @GetMapping("/test/{testId}")
    public ResponseEntity<List<TestResult>> getByTest(@PathVariable Long testId) {
        List<TestResult> results = resultService.getResultsByTest(testId);
        if (results.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(results);
    }

    // Get all results
    @GetMapping("/all")
    public ResponseEntity<List<TestResult>> getAllResults() {
        List<TestResult> results = resultService.getAllResults();
        if (results.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(results);
    }
}
