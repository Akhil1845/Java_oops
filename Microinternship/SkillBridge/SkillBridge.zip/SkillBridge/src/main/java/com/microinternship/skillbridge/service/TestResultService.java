package com.microinternship.skillbridge.service;

import com.microinternship.skillbridge.entity.Test;
import com.microinternship.skillbridge.entity.Student;
import com.microinternship.skillbridge.entity.TestResult;
import com.microinternship.skillbridge.repository.TestResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestResultService {

    @Autowired
    private TestResultRepository resultRepository;

    public TestResult saveResult(TestResult result) {
        return resultRepository.save(result);
    }

    public TestResult createResult(Student student, Test test, Integer marks) {
        TestResult r = new TestResult(student, test, marks, test.getMaxMarks());
        return resultRepository.save(r);
    }

    /** Get all results for a student by studentId */
    public List<TestResult> getResultsByStudent(Long studentId) {
        return resultRepository.findByStudent_Id(studentId);
    }

    /** Get all results for a particular test by testId */
    public List<TestResult> getResultsByTest(Long testId) {
        return resultRepository.findByTest_Id(testId);
    }

    /** Get all results (for admin/client dashboard) */
    public List<TestResult> getAllResults() {
        return resultRepository.findAll();
    }
}
