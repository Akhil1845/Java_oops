package com.microinternship.skillbridge.repository;

import com.microinternship.skillbridge.entity.TestResult;
import com.microinternship.skillbridge.entity.Student;
import com.microinternship.skillbridge.entity.Test;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TestResultRepository extends JpaRepository<TestResult, Long> {

    // Using the whole Student/Test object
    List<TestResult> findByStudent(Student student);

    List<TestResult> findByTest(Test test);

    // OR if you want to use only IDs, navigate into the relation
    List<TestResult> findByStudent_Id(Long studentId);

    List<TestResult> findByTest_Id(Long testId);
}
