package com.microinternship.skillbridge.controller;

import com.microinternship.skillbridge.entity.InternshipEnrollment;
import com.microinternship.skillbridge.service.InternshipEnrollmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
@CrossOrigin(origins = "*")
public class InternshipEnrollmentController {

    private final InternshipEnrollmentService service;

    public InternshipEnrollmentController(InternshipEnrollmentService service) {
        this.service = service;
    }

    @PostMapping("/apply")
    public InternshipEnrollment apply(@RequestParam Long studentId,
                                      @RequestParam Long internshipId) {
        return service.apply(studentId, internshipId);
    }

    @GetMapping("/student/{studentId}")
    public List<InternshipEnrollment> getByStudent(@PathVariable Long studentId) {
        return service.getByStudent(studentId);
    }

    @PutMapping("/{id}/status")
    public InternshipEnrollment updateStatus(@PathVariable Long id,
                                             @RequestParam InternshipEnrollment.Status status) {
        return service.updateStatus(id, status);
    }
}
