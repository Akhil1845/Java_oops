package com.microinternship.skillbridge.service;

import com.microinternship.skillbridge.entity.Internship;
import com.microinternship.skillbridge.entity.Student;
import com.microinternship.skillbridge.repository.InternshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class InternshipService {

    @Autowired
    private InternshipRepository internshipRepository;

    // Create a new Internship
    public Internship createInternship(String title, String company, String description, String domain) {
        Internship internship = new Internship(title, company, description, domain);
        internship.setStudents(new HashSet<>()); // initialize empty Set
        return internshipRepository.save(internship);
    }

    // Assign a student to an internship
    public Internship assignStudent(Internship internship, Student student) {
        Set<Student> students = internship.getStudents();
        if (students == null) {
            students = new HashSet<>();
        }
        students.add(student);
        internship.setStudents(students);
        return internshipRepository.save(internship);
    }

    // Get all internships
    public List<Internship> getAllInternships() {
        return internshipRepository.findAll();
    }

    // Get an internship by ID
    public Optional<Internship> getInternshipById(Long id) {
        return internshipRepository.findById(id);
    }
}
