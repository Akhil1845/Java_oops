package com.microinternship.skillbridge.repository;

import com.microinternship.skillbridge.entity.InternshipEnrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InternshipEnrollmentRepository extends JpaRepository<InternshipEnrollment, Long> {
    List<InternshipEnrollment> findByStudentId(Long studentId);
    List<InternshipEnrollment> findByInternshipId(Long internshipId);
}
