package com.microinternship.skillbridge.service;

import com.microinternship.skillbridge.entity.Internship;
import com.microinternship.skillbridge.entity.InternshipEnrollment;
import com.microinternship.skillbridge.entity.Student;
import com.microinternship.skillbridge.repository.InternshipEnrollmentRepository;
import com.microinternship.skillbridge.repository.InternshipRepository;
import com.microinternship.skillbridge.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class InternshipEnrollmentService {

    private final InternshipEnrollmentRepository enrollmentRepo;
    private final StudentRepository studentRepo;
    private final InternshipRepository internshipRepo;

    public InternshipEnrollmentService(InternshipEnrollmentRepository enrollmentRepo,
                                       StudentRepository studentRepo,
                                       InternshipRepository internshipRepo) {
        this.enrollmentRepo = enrollmentRepo;
        this.studentRepo = studentRepo;
        this.internshipRepo = internshipRepo;
    }

    public InternshipEnrollment apply(Long studentId, Long internshipId) {
        Student student = studentRepo.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        Internship internship = internshipRepo.findById(internshipId)
                .orElseThrow(() -> new RuntimeException("Internship not found"));

        InternshipEnrollment enrollment = new InternshipEnrollment();
        enrollment.setStudent(student);
        enrollment.setInternship(internship);
        enrollment.setStatus(InternshipEnrollment.Status.APPLIED);
        enrollment.setAppliedOn(LocalDate.now());
        return enrollmentRepo.save(enrollment);
    }

    public List<InternshipEnrollment> getByStudent(Long studentId) {
        return enrollmentRepo.findByStudentId(studentId);
    }

    public InternshipEnrollment updateStatus(Long enrollmentId, InternshipEnrollment.Status status) {
        InternshipEnrollment e = enrollmentRepo.findById(enrollmentId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
        e.setStatus(status);
        if (status == InternshipEnrollment.Status.COMPLETED) {
            e.setCompletedOn(LocalDate.now());
        }
        return enrollmentRepo.save(e);
    }
}
