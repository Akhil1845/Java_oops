package com.microinternship.skillbridge.service;

import com.microinternship.skillbridge.entity.Student;
import com.microinternship.skillbridge.entity.Test;
import com.microinternship.skillbridge.repository.TestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.Map;

@Service
public class TestService {

    @Autowired
    private TestRepository testRepository;

    // Save a new test
    public Test saveTest(Test test) {
        if (test.getStudents() == null) {
            test.setStudents(new HashSet<>());
        }
        return testRepository.save(test);
    }

    // Get all tests
    public List<Test> getAllTests() {
        return testRepository.findAll();
    }

    // Get tests by clientId
    public List<Test> getTestsByClient(Long clientId) {
        return testRepository.findByClientId(clientId);
    }

    // Get a test by ID
    public Optional<Test> getTestById(Long id) {
        return testRepository.findById(id);
    }

    // Assign a student to a test
    public Test assignStudent(Test test, Student student) {
        Set<Student> students = test.getStudents();
        students.add(student);
        test.setStudents(students);
        return testRepository.save(test);
    }

    // Update questions for a test
    public Test updateQuestions(Long testId, List<Map<String,Object>> questions) {
        Optional<Test> testOpt = testRepository.findById(testId);
        if(testOpt.isEmpty()) return null;
        Test test = testOpt.get();
        test.setQuestions(questions);
        return testRepository.save(test);
    }
}
